// ============================================================
// routes/animalRoutes.js
// ------------------------------------------------------------
// PURPOSE: Defines which URL + HTTP method combination triggers
// which controller function. This is the "map" of our API —
// no business logic lives here, just traffic routing.
// ============================================================

const express = require("express");
const router = express.Router();

const {
  createAnimal,
  getAnimals,
  getAnimalById,
  updateAnimalStatus,
  deleteAnimal,
} = require("../controllers/animalController");

// ------------------------------------------------------------
// REST convention reminder:
//   GET    -> read data
//   POST   -> create data
//   PUT    -> update data
//   DELETE -> remove data
// ------------------------------------------------------------

// GET  /api/animals  -> list all (optionally ?requestType=Rescue|Adoption)
// POST /api/animals  -> create a new rescue report or adoption listing
router.route("/").get(getAnimals).post(createAnimal);

// GET    /api/animals/:id -> fetch one record
// PUT    /api/animals/:id -> update its status
// DELETE /api/animals/:id -> delete it
router
  .route("/:id")
  .get(getAnimalById)
  .put(updateAnimalStatus)
  .delete(deleteAnimal);

module.exports = router;
