// ============================================================
// server.js
// ------------------------------------------------------------
// PURPOSE: The ENTRY POINT of the backend — the file you run
// with "node server.js". It loads config, connects to MongoDB,
// sets up Express middleware, wires in our routes, and starts
// listening for requests.
// ============================================================

// Load variables from .env into process.env. Must run first,
// before anything that depends on those values (like connectDB).
require("dotenv").config();

const express = require("express");

// cors lets our React app (a different origin/port) call this API
// without the browser blocking the request for security reasons.
const cors = require("cors");

const connectDB = require("./config/db");
const animalRoutes = require("./routes/animalRoutes");

// Attempt the MongoDB connection as soon as the app starts.
connectDB();

const app = express();

// ------------------------------------------------------------
// MIDDLEWARE — functions that run on every incoming request
// BEFORE it reaches our route handlers.
// ------------------------------------------------------------
app.use(cors());

// Parses incoming JSON request bodies (like the data Axios sends)
// into a plain JS object available at req.body.
app.use(express.json());

// ------------------------------------------------------------
// ROUTES
// ------------------------------------------------------------
// Any URL starting with "/api/animals" is handled by animalRoutes.
app.use("/api/animals", animalRoutes);

// Simple health-check route so visiting the root URL confirms
// the server is alive.
app.get("/", (req, res) => {
  res.send("Animal Rescue and Adoption Platform API is running...");
});

// ------------------------------------------------------------
// START LISTENING
// ------------------------------------------------------------
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
