// ============================================================
// controllers/animalController.js
// ------------------------------------------------------------
// PURPOSE: Contains the actual logic behind each API endpoint.
// Routes just say WHICH URL triggers a function; this file says
// WHAT that function actually does.
// ============================================================

const Animal = require("../models/Animal");

// ------------------------------------------------------------
// @desc   Create a new animal record (a rescue report OR an
//         adoption listing — decided by req.body.requestType)
// @route  POST /api/animals
// ------------------------------------------------------------
const createAnimal = async (req, res) => {
  try {
    // Pull out exactly the fields we expect from the request body
    // (sent as JSON by the React frontend).
    const {
      name,
      species,
      breed,
      age,
      location,
      description,
      reporterName,
      reporterEmail,
      requestType,
    } = req.body;

    // Validate the fields that are REQUIRED by our schema.
    // Checking here first gives a clear 400 error instead of a
    // confusing Mongoose validation error later.
    if (!species || !location || !description || !reporterName || !reporterEmail || !requestType) {
      return res.status(400).json({ message: "Please fill in all required fields." });
    }

    // Animal.create() builds a new document using our schema AND
    // saves it to MongoDB in one step. Fields we don't pass here
    // (like "status") automatically fall back to their schema
    // defaults ("Pending").
    const newAnimal = await Animal.create({
      name,
      species,
      breed,
      age,
      location,
      description,
      reporterName,
      reporterEmail,
      requestType,
    });

    // 201 = "Created" — the standard status code for a successful
    // resource-creation request.
    res.status(201).json(newAnimal);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ------------------------------------------------------------
// @desc   Get ALL animal records, optionally filtered by
//         requestType via a query string, e.g.
//         GET /api/animals?requestType=Adoption
// @route  GET /api/animals
// ------------------------------------------------------------
const getAnimals = async (req, res) => {
  try {
    // req.query holds anything after the "?" in the URL, parsed
    // into a plain object, e.g. ?requestType=Adoption becomes
    // { requestType: "Adoption" }.
    const { requestType } = req.query;

    // Build our MongoDB filter object dynamically:
    // - if a requestType was given in the URL, filter by it
    // - otherwise, pass an empty object {} which means "no filter,
    //   return everything" (this is how MongoDB/Mongoose queries work)
    const filter = requestType ? { requestType } : {};

    // .sort({ createdAt: -1 }) orders newest-first (-1 = descending)
    const animals = await Animal.find(filter).sort({ createdAt: -1 });

    res.status(200).json(animals);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ------------------------------------------------------------
// @desc   Get a single animal record by its MongoDB _id
// @route  GET /api/animals/:id
// ------------------------------------------------------------
const getAnimalById = async (req, res) => {
  try {
    // req.params.id captures whatever is in the ":id" slot of the
    // URL, e.g. /api/animals/64f3a2 -> req.params.id === "64f3a2"
    const animal = await Animal.findById(req.params.id);

    if (!animal) {
      return res.status(404).json({ message: "Animal record not found." });
    }

    res.status(200).json(animal);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ------------------------------------------------------------
// @desc   Update an animal record's status
//         (e.g. Pending -> In Progress -> Resolved)
// @route  PUT /api/animals/:id
// ------------------------------------------------------------
const updateAnimalStatus = async (req, res) => {
  try {
    const { status } = req.body;

    // findByIdAndUpdate(idToFind, changesToApply, options)
    // "new: true" makes it return the UPDATED document instead
    // of the old one; "runValidators: true" re-checks schema
    // rules (like the "enum" list) against the new value.
    const updatedAnimal = await Animal.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    );

    if (!updatedAnimal) {
      return res.status(404).json({ message: "Animal record not found." });
    }

    res.status(200).json(updatedAnimal);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ------------------------------------------------------------
// @desc   Delete an animal record entirely
// @route  DELETE /api/animals/:id
// ------------------------------------------------------------
const deleteAnimal = async (req, res) => {
  try {
    const deletedAnimal = await Animal.findByIdAndDelete(req.params.id);

    if (!deletedAnimal) {
      return res.status(404).json({ message: "Animal record not found." });
    }

    res.status(200).json({ message: "Animal record deleted successfully." });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

module.exports = {
  createAnimal,
  getAnimals,
  getAnimalById,
  updateAnimalStatus,
  deleteAnimal,
};
