// ============================================================
// models/Animal.js
// ------------------------------------------------------------
// PURPOSE: Defines the SHAPE of an "Animal" document as stored
// in MongoDB. One single model covers BOTH use cases the
// platform needs — reporting an animal that needs rescue, and
// posting an animal that's available for adoption — because
// both are really "a record about an animal with a status that
// changes over time". The "requestType" field is what tells
// the two apart.
// ============================================================

const mongoose = require("mongoose");

const animalSchema = new mongoose.Schema(
  {
    // The animal's name, if known. Many rescued strays won't
    // have one yet, so this is NOT required — we default to
    // a friendly placeholder instead of forcing the reporter
    // to invent a name.
    name: {
      type: String,
      trim: true,
      default: "Unknown",
    },

    // What kind of animal this is. Using "enum" restricts the
    // value to this fixed list, which keeps our data clean and
    // makes it easy to filter/search later (e.g. "show all Dogs").
    species: {
      type: String,
      enum: ["Dog", "Cat", "Bird", "Other"],
      required: true,
    },

    // Optional breed information, plain free text since breeds
    // are too varied to restrict with an enum.
    breed: {
      type: String,
      trim: true,
      default: "Not specified",
    },

    // Approximate age in years. Not required, since a rescuer
    // finding a stray animal often has no way to know its exact age.
    age: {
      type: Number,
      min: 0,
    },

    // Where the animal was found / is currently located.
    // Important for anyone coordinating an actual rescue.
    location: {
      type: String,
      required: true,
      trim: true,
    },

    // Free-text details: condition of the animal if it's a rescue
    // case ("injured leg, found near the highway"), or
    // personality/care details if it's up for adoption
    // ("friendly, vaccinated, good with kids").
    description: {
      type: String,
      required: true,
    },

    // Who is submitting this post — the person reporting the
    // rescue case, or the person offering the animal for adoption.
    reporterName: {
      type: String,
      required: true,
      trim: true,
    },
    reporterEmail: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
    },

    // This is the KEY field that distinguishes the two purposes
    // of the platform mentioned in the brief: reporting an animal
    // that needs help, versus offering one for adoption.
    requestType: {
      type: String,
      enum: ["Rescue", "Adoption"],
      required: true,
    },

    // The lifecycle status of this record. The MEANING of each
    // value depends on requestType:
    //   Rescue posts:   Pending -> In Progress -> Resolved (rescued)
    //   Adoption posts: Pending -> In Progress -> Resolved (adopted)
    // Using the same three-stage flow for both keeps the whole
    // app consistent and simple to reason about.
    status: {
      type: String,
      enum: ["Pending", "In Progress", "Resolved"],
      default: "Pending",
    },
  },
  {
    // Automatically adds and maintains "createdAt" / "updatedAt"
    // fields on every document — no manual bookkeeping needed.
    timestamps: true,
  }
);

// Turn the schema into a Model we can query/create/update/delete
// with. Mongoose stores these in a collection named "animals"
// (lowercased, pluralized automatically from "Animal").
const Animal = mongoose.model("Animal", animalSchema);

module.exports = Animal;
