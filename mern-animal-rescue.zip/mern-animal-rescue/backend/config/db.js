// ============================================================
// config/db.js
// ------------------------------------------------------------
// PURPOSE: Isolates the "connect to MongoDB" logic in one place,
// separate from server.js, so it's easy to find and reuse.
// ============================================================

const mongoose = require("mongoose");

// An async function because opening a network connection to a
// database takes time, and we want to wait for it to finish
// (or fail) before the rest of the app continues.
const connectDB = async () => {
  try {
    // mongoose.connect() reads the connection string from our
    // .env file (process.env.MONGO_URI) and attempts to connect.
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    // If the connection fails (wrong URI, DB offline, etc.),
    // log the reason and shut the whole app down — there's no
    // point running a server that can't reach its database.
    console.error(`Error connecting to MongoDB: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;
