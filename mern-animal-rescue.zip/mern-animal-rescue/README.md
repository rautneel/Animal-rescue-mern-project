# Animal Rescue and Adoption Platform (MERN Stack)

A beginner-friendly, fully-commented MERN stack project. Every file has
line-by-line comments explaining not just *what* the code does, but *why* —
so someone with no prior MERN experience can read the code as a tutorial.

## What does the app do?

- Users can **report an animal that needs rescue** (species, condition, location, reporter details).
- Users can **list an animal available for adoption** (same form, different mode).
- All records are stored in MongoDB and shown in a single list, filterable by "Rescue" / "Adoption" / "All".
- Each record has a status: **Pending → In Progress → Resolved** (Resolved means "rescued" or "adopted" depending on type).
- Records can be deleted.

One data model (`Animal`) with a `requestType` field covers both the rescue
and adoption use cases, keeping the CRUD pattern simple and consistent.

## What does "MERN" mean?

| Letter | Technology | Role in this project |
|---|---|---|
| **M** | **MongoDB** | Database. Stores each animal record as a document in an `animals` collection. |
| **E** | **Express.js** | Node.js web framework. Defines the API's URLs ("routes") and handles requests. |
| **R** | **React** | Frontend library. Builds the UI from components and re-renders automatically when data changes. |
| **N** | **Node.js** | The JavaScript runtime that runs our Express server outside the browser. |

**React (in the browser) talks to Express (on Node.js) over HTTP requests,
and Express talks to MongoDB to save/retrieve data.**

## The full request/response flow

What happens when a user submits the "Report a Rescue" form:

```
 1. USER fills the form and clicks "Submit Rescue Report"
        │
        ▼
 2. AnimalForm.js runs handleSubmit()
    - Reads form data from React state
    - Calls createAnimal(payload) from src/api/api.js
        │
        ▼
 3. Axios sends an HTTP POST request to
    http://localhost:5000/api/animals with the data as JSON
        │
        ▼
 4. Express (backend/server.js) receives it
    - express.json() middleware parses the JSON into req.body
    - URL starts with /api/animals -> handed to animalRoutes.js
        │
        ▼
 5. animalRoutes.js matches POST "/" to createAnimal()
    in animalController.js
        │
        ▼
 6. createAnimal() validates the data, then calls
    Animal.create({...}) — using the Mongoose MODEL
    (models/Animal.js) that defines the schema/shape
        │
        ▼
 7. Mongoose inserts the document into MongoDB's "animals"
    collection; MongoDB generates a unique _id and a default
    status of "Pending", then returns the saved document
        │
        ▼
 8. The controller sends that document back as JSON with
    status 201 (Created)
        │
        ▼
 9. Axios (in the browser) receives the response;
    createAnimal() in api.js returns response.data
        │
        ▼
10. AnimalForm.js calls onAnimalAdded(newAnimal) — a function
    passed down from App.js
        │
        ▼
11. App.js's handleAnimalAdded() adds the new record to its
    "animals" state array
        │
        ▼
12. React detects the state change and RE-RENDERS —
    AnimalList.js shows the new entry immediately, with NO
    page reload.
```

Fetching the list (with the Rescue/Adoption/All filter), updating status,
and deleting all follow the same shape: **React event → Axios request →
Express route → Controller → Mongoose/MongoDB → JSON response → React state
update → UI re-renders.**

## Project structure

```
mern-animal-rescue/
├── backend/
│   ├── config/db.js                    # Connects to MongoDB
│   ├── models/Animal.js                # Mongoose schema (data shape)
│   ├── controllers/animalController.js # Business logic for each endpoint
│   ├── routes/animalRoutes.js          # Maps URLs + HTTP methods to controllers
│   ├── server.js                       # Entry point — starts the Express server
│   ├── .env.example                    # Template for environment variables
│   └── package.json
└── frontend/
    ├── public/index.html               # The single real HTML page
    └── src/
        ├── index.js                    # React entry point
        ├── App.js                      # Top-level component; owns state + filter tabs
        ├── api/api.js                  # All Axios calls to the backend, centralized
        └── components/
            ├── Header.js
            ├── AnimalForm.js           # Create a rescue report or adoption listing
            ├── AnimalList.js           # Renders the filtered list
            └── AnimalItem.js           # One record card (update status / delete)
```

## API Endpoints (Express side)

| Method | URL | What it does |
|---|---|---|
| GET | `/api/animals` | Fetch all records |
| GET | `/api/animals?requestType=Rescue` | Fetch only rescue reports |
| GET | `/api/animals?requestType=Adoption` | Fetch only adoption listings |
| POST | `/api/animals` | Create a new record |
| GET | `/api/animals/:id` | Fetch one record by ID |
| PUT | `/api/animals/:id` | Update a record's status |
| DELETE | `/api/animals/:id` | Delete a record |

## How to run it yourself

### Prerequisites
- Node.js (v18+ recommended)
- MongoDB running locally, or a free MongoDB Atlas cloud cluster

### 1. Backend setup
```bash
cd backend
npm install
cp .env.example .env
# Edit .env if needed (set your MongoDB URI)
npm run dev      # http://localhost:5000 (requires nodemon)
# or: npm start
```

### 2. Frontend setup (new terminal)
```bash
cd frontend
npm install
npm start         # http://localhost:3000, opens automatically
```

Start the backend first — the frontend's initial data fetch will fail
silently (check the browser console) if the API isn't running yet.

## Key MERN concepts demonstrated (and where)

| Concept | Where to look |
|---|---|
| Schema/Model with a shared status flow for two use cases | `backend/models/Animal.js` |
| Query-string filtering (`?requestType=...`) | `backend/controllers/animalController.js` → `getAnimals` |
| Middleware (`cors`, `express.json`) | `backend/server.js` |
| REST routing | `backend/routes/animalRoutes.js` |
| CRUD logic / async-await with Mongoose | `backend/controllers/animalController.js` |
| React state (`useState`) | `App.js`, `AnimalForm.js` |
| `useEffect` re-running when a dependency (filter) changes | `App.js` |
| Controlled form inputs + a toggle within one form | `AnimalForm.js` |
| Lifting state up / callback props | `App.js` passing functions to its children |
| Rendering lists with `.map()` and `key` props | `AnimalList.js` |
| Centralized API layer with Axios | `src/api/api.js` |

## Possible next steps (if you want to extend it)

- Add image upload for each animal (e.g. via Cloudinary or local file storage).
- Add authentication so only verified rescuers/shelters can mark a record "Resolved".
- Add a map view showing rescue locations.
- Deploy the backend (Render/Railway) and frontend (Vercel/Netlify), using MongoDB Atlas for the database.
