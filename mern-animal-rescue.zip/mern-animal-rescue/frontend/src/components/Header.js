// ============================================================
// src/components/Header.js
// ------------------------------------------------------------
// PURPOSE: The simplest possible React component — a title
// banner. Shows the basic building block of React: a function
// that returns JSX (HTML-like syntax).
// ============================================================

import React from "react";

function Header() {
  return (
    <div>
      <h1>Animal Rescue &amp; Adoption Platform</h1>
      <p style={{ textAlign: "center", color: "#666" }}>
        Report animals in need of rescue, or list animals available for adoption.
      </p>
    </div>
  );
}

export default Header;
