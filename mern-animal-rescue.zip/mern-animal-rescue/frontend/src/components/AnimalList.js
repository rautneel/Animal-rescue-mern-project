// ============================================================
// src/components/AnimalList.js
// ------------------------------------------------------------
// PURPOSE: Takes an ARRAY of animal records and renders one
// <AnimalItem /> per record — the standard React pattern of
// turning a data array into a UI list using .map().
// ============================================================

import React from "react";
import AnimalItem from "./AnimalItem";

function AnimalList({ animals, onStatusChange, onDelete }) {
  if (animals.length === 0) {
    return <p style={{ textAlign: "center", color: "#888" }}>No records to show.</p>;
  }

  return (
    <div>
      {animals.map((animal) => (
        <AnimalItem
          // React needs a unique "key" on every item in a list so
          // it can efficiently detect additions/removals/changes.
          // MongoDB's auto-generated _id is perfect for this.
          key={animal._id}
          animal={animal}
          onStatusChange={onStatusChange}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
}

export default AnimalList;
