// ============================================================
// src/components/AnimalItem.js
// ------------------------------------------------------------
// PURPOSE: Renders ONE animal record as a card, with a status
// dropdown and a delete button. Shows how a CHILD component
// triggers PUT/DELETE calls and reports results back UP to the
// parent (App.js) via callback props.
// ============================================================

import React from "react";
import { updateAnimalStatus, deleteAnimal } from "../api/api";

// Props:
// - animal: the record to display
// - onStatusChange: called with the updated record after a successful PUT
// - onDelete: called with the deleted record's ID after a successful DELETE
function AnimalItem({ animal, onStatusChange, onDelete }) {
  const handleStatusChange = async (e) => {
    const newStatus = e.target.value;
    try {
      // Persist the new status in MongoDB via the backend.
      const updated = await updateAnimalStatus(animal._id, newStatus);

      // Hand the fresh, updated record back up to App.js so it
      // can refresh what's shown on screen.
      onStatusChange(updated);
    } catch (error) {
      console.error("Failed to update status:", error);
      alert("Could not update status.");
    }
  };

  const handleDelete = async () => {
    const confirmed = window.confirm("Delete this record permanently?");
    if (!confirmed) return;

    try {
      await deleteAnimal(animal._id);
      // Tell the parent which ID to remove from the displayed list.
      onDelete(animal._id);
    } catch (error) {
      console.error("Failed to delete record:", error);
      alert("Could not delete record.");
    }
  };

  // CSS class names can't contain spaces, so "In Progress"
  // becomes "In-Progress" for the class name only.
  const statusClass = `status-badge status-${animal.status.replace(" ", "-")}`;
  const typeClass = `type-badge type-${animal.requestType}`;

  return (
    <div className="animal-card">
      <strong>
        {animal.name} — {animal.species}
        {animal.breed !== "Not specified" ? ` (${animal.breed})` : ""}
      </strong>
      <div className="badge-row">
        <span className={typeClass}>{animal.requestType}</span>
        <span className={statusClass}>{animal.status}</span>
      </div>
      <p>
        <strong>Location:</strong> {animal.location}
        {animal.age ? ` · Age: ${animal.age}` : ""}
      </p>
      <p>{animal.description}</p>
      <p style={{ fontSize: "13px", color: "#777" }}>
        Reported by {animal.reporterName} ({animal.reporterEmail})
      </p>

      <div className="card-actions">
        <select value={animal.status} onChange={handleStatusChange}>
          <option value="Pending">Pending</option>
          <option value="In Progress">In Progress</option>
          <option value="Resolved">
            {animal.requestType === "Rescue" ? "Resolved (Rescued)" : "Resolved (Adopted)"}
          </option>
        </select>

        <button className="delete-btn" onClick={handleDelete}>
          Delete
        </button>
      </div>
    </div>
  );
}

export default AnimalItem;
