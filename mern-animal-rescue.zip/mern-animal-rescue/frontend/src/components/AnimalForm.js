// ============================================================
// src/components/AnimalForm.js
// ------------------------------------------------------------
// PURPOSE: A single form that handles BOTH use cases of the
// platform — reporting an animal needing rescue, and listing
// an animal for adoption — switched by a "requestType" field.
// Demonstrates controlled inputs, one shared state object for
// a multi-field form, and lifting state up via a callback prop.
// ============================================================

import React, { useState } from "react";
import { createAnimal } from "../api/api";

// "onAnimalAdded" is a function passed down from App.js (the
// parent), which we call after successfully creating a record.
function AnimalForm({ onAnimalAdded }) {
  // One state object holds every field in the form. Using a
  // single object (rather than one useState per field) keeps
  // the component simple when there are many related inputs.
  const [formData, setFormData] = useState({
    requestType: "Rescue", // default tab when the form first loads
    name: "",
    species: "Dog",
    breed: "",
    age: "",
    location: "",
    description: "",
    reporterName: "",
    reporterEmail: "",
  });

  const [submitting, setSubmitting] = useState(false);

  // Runs on every keystroke/selection change in any field.
  // We rely on each input's "name" attribute to know which key
  // of formData to update.
  const handleChange = (e) => {
    const { name, value } = e.target;

    // Spread the existing formData, then overwrite just the one
    // field that changed. React state must always be replaced
    // with a NEW object, never mutated directly.
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    // Stops the browser's default "reload the page on submit"
    // behavior, so React stays in control of what happens next.
    e.preventDefault();

    setSubmitting(true);
    try {
      // Send the form data to the backend. If "age" was left
      // blank, we send it as undefined rather than an empty
      // string, since our schema expects a Number or nothing.
      const payload = { ...formData, age: formData.age ? Number(formData.age) : undefined };

      const newAnimal = await createAnimal(payload);

      // Tell App.js a new record was created, passing the full
      // saved document (which now includes _id and status).
      onAnimalAdded(newAnimal);

      // Reset the form, but keep the same requestType tab selected
      // so the user can quickly submit another similar entry.
      setFormData({
        requestType: formData.requestType,
        name: "",
        species: "Dog",
        breed: "",
        age: "",
        location: "",
        description: "",
        reporterName: "",
        reporterEmail: "",
      });
    } catch (error) {
      console.error("Failed to submit:", error);
      alert("Something went wrong while submitting the form.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* A simple toggle between the two purposes of the form.
          Both buttons just update the SAME "requestType" field. */}
      <div className="tabs">
        <button
          type="button" // type="button" prevents this from submitting the form
          className={`tab-btn ${formData.requestType === "Rescue" ? "active" : ""}`}
          onClick={() => setFormData({ ...formData, requestType: "Rescue" })}
        >
          Report a Rescue
        </button>
        <button
          type="button"
          className={`tab-btn ${formData.requestType === "Adoption" ? "active" : ""}`}
          onClick={() => setFormData({ ...formData, requestType: "Adoption" })}
        >
          List for Adoption
        </button>
      </div>

      <label>Animal's Name (if known)</label>
      <input
        type="text"
        name="name"
        value={formData.name}
        onChange={handleChange}
        placeholder="e.g. Bruno, or leave blank"
      />

      <label>Species</label>
      <select name="species" value={formData.species} onChange={handleChange}>
        <option value="Dog">Dog</option>
        <option value="Cat">Cat</option>
        <option value="Bird">Bird</option>
        <option value="Other">Other</option>
      </select>

      <label>Breed (optional)</label>
      <input type="text" name="breed" value={formData.breed} onChange={handleChange} />

      <label>Approximate Age (years, optional)</label>
      <input type="number" name="age" min="0" value={formData.age} onChange={handleChange} />

      <label>Location</label>
      <input
        type="text"
        name="location"
        value={formData.location}
        onChange={handleChange}
        placeholder="Where the animal is / was found"
        required
      />

      <label>
        {formData.requestType === "Rescue"
          ? "Describe the animal's condition"
          : "Describe the animal (temperament, vaccination, etc.)"}
      </label>
      <textarea
        name="description"
        rows="3"
        value={formData.description}
        onChange={handleChange}
        required
      />

      <label>Your Name</label>
      <input
        type="text"
        name="reporterName"
        value={formData.reporterName}
        onChange={handleChange}
        required
      />

      <label>Your Email</label>
      <input
        type="email"
        name="reporterEmail"
        value={formData.reporterEmail}
        onChange={handleChange}
        required
      />

      <button type="submit" disabled={submitting}>
        {submitting
          ? "Submitting..."
          : formData.requestType === "Rescue"
          ? "Submit Rescue Report"
          : "Submit Adoption Listing"}
      </button>
    </form>
  );
}

export default AnimalForm;
