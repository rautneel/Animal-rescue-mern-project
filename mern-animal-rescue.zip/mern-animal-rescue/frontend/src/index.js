// ============================================================
// src/index.js
// ------------------------------------------------------------
// PURPOSE: The JavaScript entry point of the React app. Takes
// our top-level <App /> component and mounts it onto the real
// "root" div defined in public/index.html.
// ============================================================

import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";

// Attach a React "root" to the actual DOM element with id="root".
const root = ReactDOM.createRoot(document.getElementById("root"));

// React.StrictMode is a development-only helper that runs some
// checks twice to catch potential bugs early — it has no effect
// on the production build.
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
