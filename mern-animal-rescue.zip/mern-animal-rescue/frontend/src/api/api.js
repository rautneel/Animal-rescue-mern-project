// ============================================================
// src/api/api.js
// ------------------------------------------------------------
// PURPOSE: Centralizes every HTTP call to the backend in one
// place. Components call these functions instead of writing
// axios.get/post/put/delete scattered across the codebase —
// if the backend URL ever changes, we only update it HERE.
// ============================================================

import axios from "axios";

// Base URL of our Express API (see backend/server.js, port 5000).
const BASE_URL = "http://localhost:5000/api/animals";

// Fetch animal records. Optionally pass a requestType
// ("Rescue" or "Adoption") to filter server-side; pass nothing
// (or "All") to fetch everything.
// Corresponds to: GET /api/animals?requestType=...
export const fetchAnimals = async (requestType) => {
  // axios.get(url, { params }) automatically turns the params
  // object into a query string, e.g. { requestType: "Adoption" }
  // becomes "?requestType=Adoption" appended to the URL.
  const params = requestType && requestType !== "All" ? { requestType } : {};
  const response = await axios.get(BASE_URL, { params });
  return response.data;
};

// Submit a new rescue report or adoption listing.
// Corresponds to: POST /api/animals
export const createAnimal = async (animalData) => {
  // axios.post(url, body) sends animalData as a JSON body and
  // sets the "Content-Type: application/json" header for us.
  const response = await axios.post(BASE_URL, animalData);
  return response.data;
};

// Update just the status field of one record.
// Corresponds to: PUT /api/animals/:id
export const updateAnimalStatus = async (id, newStatus) => {
  const response = await axios.put(`${BASE_URL}/${id}`, { status: newStatus });
  return response.data;
};

// Delete a record permanently.
// Corresponds to: DELETE /api/animals/:id
export const deleteAnimal = async (id) => {
  const response = await axios.delete(`${BASE_URL}/${id}`);
  return response.data;
};
