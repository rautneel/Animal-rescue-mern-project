// ============================================================
// src/App.js
// ------------------------------------------------------------
// PURPOSE: The TOP-LEVEL component. It "owns" the master list
// of animal records in its state, re-fetches from the backend
// whenever the active filter tab changes (useEffect with a
// dependency), and passes data + update functions DOWN to its
// children (AnimalForm, AnimalList). This is the "lifting state
// up" pattern — children never store the master data themselves.
// ============================================================

import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import AnimalForm from "./components/AnimalForm";
import AnimalList from "./components/AnimalList";
import { fetchAnimals } from "./api/api";

function App() {
  // The full array of records currently displayed.
  const [animals, setAnimals] = useState([]);

  // Which tab is active: "All", "Rescue", or "Adoption".
  // This drives which records we ask the backend for.
  const [filter, setFilter] = useState("All");

  // Shows a loading message during the initial/refetch requests.
  const [loading, setLoading] = useState(true);

  // ----------------------------------------------------------
  // useEffect with [filter] as its dependency array means:
  // "run this effect once immediately, AND again every time the
  // 'filter' value changes." This is how switching tabs causes
  // a fresh network request with the new filter applied.
  // ----------------------------------------------------------
  useEffect(() => {
    const loadAnimals = async () => {
      setLoading(true);
      try {
        // fetchAnimals sends GET /api/animals?requestType=<filter>
        // (or no query string at all when filter is "All" —
        // see the implementation in src/api/api.js).
        const data = await fetchAnimals(filter);
        setAnimals(data);
      } catch (error) {
        console.error("Failed to load animal records:", error);
      } finally {
        setLoading(false);
      }
    };

    loadAnimals();
  }, [filter]); // re-run whenever "filter" changes

  // Called by AnimalForm after a new record is successfully
  // created on the backend.
  const handleAnimalAdded = (newAnimal) => {
    // Only prepend it to the visible list if it matches the
    // currently active filter tab (otherwise it would briefly
    // appear in a list it doesn't belong to).
    if (filter === "All" || newAnimal.requestType === filter) {
      setAnimals([newAnimal, ...animals]);
    }
  };

  // Called by AnimalList (via AnimalItem) after a status update
  // succeeds on the backend.
  const handleStatusChange = (updatedAnimal) => {
    setAnimals(
      animals.map((a) => (a._id === updatedAnimal._id ? updatedAnimal : a))
    );
  };

  // Called after a record is successfully deleted on the backend.
  const handleDelete = (deletedId) => {
    setAnimals(animals.filter((a) => a._id !== deletedId));
  };

  return (
    <div className="container">
      <Header />

      {/* AnimalForm doesn't know or care how App.js uses new
          records — it just calls onAnimalAdded after success. */}
      <AnimalForm onAnimalAdded={handleAnimalAdded} />

      <h2>Listings</h2>

      {/* Filter tabs — clicking one just updates "filter" state,
          which triggers the useEffect above to refetch. */}
      <div className="tabs">
        {["All", "Rescue", "Adoption"].map((option) => (
          <button
            key={option}
            className={`tab-btn ${filter === option ? "active" : ""}`}
            onClick={() => setFilter(option)}
          >
            {option}
          </button>
        ))}
      </div>

      {loading ? (
        <p style={{ textAlign: "center" }}>Loading...</p>
      ) : (
        <AnimalList
          animals={animals}
          onStatusChange={handleStatusChange}
          onDelete={handleDelete}
        />
      )}
    </div>
  );
}

export default App;
